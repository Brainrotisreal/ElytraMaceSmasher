package me.autobot.elytramace.mixin;

import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1657;
import net.minecraft.class_1802;
import net.minecraft.class_2848;
import net.minecraft.class_634;
import net.minecraft.class_636;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_636.class)
public class MixinMultiPlayerGameMode_MaceAttack {

    @Shadow
    @Final
    private class_634 connection;
    @Unique
    private boolean smash = false;

    @Inject(method = "attack", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/multiplayer/MultiPlayerGameMode;ensureHasSentCarriedItem()V", shift = At.Shift.AFTER))
    public void onAttackWithMace(class_1657 player, class_1297 entity, CallbackInfo ci) {
        if (!player.method_5998(class_1268.field_5808).method_31574(class_1802.field_49814)) {
            return;
        }
        if (!player.method_6118(class_1304.field_6174).method_31574(class_1802.field_8833)) {
            return;
        }
        if (player.method_6128() && player.field_6017 > 1.5F) {
            smash = true;
            this.connection.method_52787(new class_2848(player, class_2848.class_2849.field_12982));
        }
    }

    @Inject(method = "attack", at = @At(value = "TAIL"))
    public void onAttackFinishedWithMace(class_1657 player, class_1297 entity, CallbackInfo ci) {
        if (smash) {
            smash = false;
            this.connection.method_52787(new class_2848(player, class_2848.class_2849.field_12982));
        }
    }
}
